

<?php $__env->startSection('title','Patient View'); ?>
<?php $__env->startSection('content'); ?>


<div class="" style="width:100%;max-width:700px;margin:auto">
<h3 class="text-center">Choose a doctor to consultant</h3>
<br>
<form method="POST" action="<?php echo e(url('/consultant-to/'.$patient_id)); ?>">
      <?php echo csrf_field(); ?>
      <select class="form-select" name="doctor_id" aria-label="Default select example">
            <option selected>Open this select menu</option>
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($item['doctor_id']); ?>">
                        <b>Name:</b><?php echo e($item['name']); ?> 
                        <b>Subject:</b><?php echo e($item['subject']); ?>

                  </option>               
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <br>
      <div class="text-center">
            <button type="submit" class="btn btn-primary">Send to Consultation</button>
      </div>
</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/consultation/consultation_room.blade.php ENDPATH**/ ?>