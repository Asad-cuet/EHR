

<?php $__env->startSection('title','Patient Registration'); ?>
<?php $__env->startSection('content'); ?>


<div class="" style="width:100%;max-width:700px;margin:auto">
<h3 class="text-center">Add Test</h3>
<form method="POST" action="<?php echo e(url('/add-test')); ?>">
      <?php echo csrf_field(); ?>


      <div class="row">
            <div class="col">
              <input required type="text" name="test_name" class="form-control" placeholder="Write Name.." aria-label="First name">
            </div>
      </div>
      <br>
      <div class="text-center">
            <button type="submit" class="btn btn-primary">Add</button>
      </div>
      
</form>
      
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/test/test_form.blade.php ENDPATH**/ ?>