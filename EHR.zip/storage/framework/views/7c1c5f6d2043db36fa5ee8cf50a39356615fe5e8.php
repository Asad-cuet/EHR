

<?php $__env->startSection('title','Patients'); ?>
<?php $__env->startSection('content'); ?>


<table class="table">
   <thead>
     <tr>
       <th scope="col">ID</th>
       <th scope="col">Patient Name</th>
       <th scope="col">Patient Phone</th>
       <th scope="col">Consulting By</th>
       <th scope="col">Action</th>
     </tr>
   </thead>
   <tbody>
      <?php $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
         <td><?php echo e($item['id']); ?></td>
         <td><?php echo e($item['patient_name']); ?></td>
         <td><?php echo e($item['patient_phone']); ?></td>
         <td><?php echo e($item['doctor_name']); ?></td>
         <td>
            <a href="<?php echo e(url('/consultation-history/'.$item['id'])); ?>" class="btn btn-info">History</a>
            <a href="<?php echo e(url('/problem/'.$item['id'])); ?>" class="btn btn-danger">Problem</a>

            <a href="<?php echo e(url('/prescribe/'.$item['id'])); ?>" class="btn btn-warning">Prescribe</a>
            <a href="<?php echo e(url('/exam/'.$item['id'])); ?>" class="btn btn-primary">Exam</a>
            <a href="#" class="btn btn-success">Exam Result</a>
         </td>
         
       </tr>       
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </tbody>
 </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/consultation/consultation_list.blade.php ENDPATH**/ ?>