    <footer class="py-4 bg-light mt-auto">
        <div class="container-fluid px-4">

        </div>
    </footer><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/layout/footer.blade.php ENDPATH**/ ?>