 <div id="layoutSidenav_nav">
          <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
              <div class="sb-sidenav-menu">
                  <div class="nav">
                      <div class="sb-sidenav-menu-heading">Core</div>
                      <a class="nav-link" href="<?php echo e(url('/')); ?>">
                          <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                          Dashboard
                      </a>
                      
                      <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                          <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                          Patients
                          <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                      </a>
                      <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                          <nav class="sb-sidenav-menu-nested nav">
                              <a class="nav-link" href="<?php echo e(url('/patients')); ?>">Patient List</a>
                              <a class="nav-link" href="<?php echo e(url('/patient-form')); ?>">Patient Registration</a>
                          </nav>
                      </div>
                      <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#doctor" aria-expanded="false" aria-controls="collapseLayouts">
                          <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                          Doctor
                          <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                      </a>
                      <div class="collapse" id="doctor" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                          <nav class="sb-sidenav-menu-nested nav">
                              <a class="nav-link" href="<?php echo e(url('/doctors')); ?>">Doctor List</a>
                              <a class="nav-link" href="<?php echo e(url('/doctor-form')); ?>">Doctor Registration</a>
                          </nav>
                      </div>
                      <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#test" aria-expanded="false" aria-controls="collapseLayouts">
                          <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                             Test
                          <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                      </a>
                      <div class="collapse" id="test" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                          <nav class="sb-sidenav-menu-nested nav">
                              <a class="nav-link" href="<?php echo e(url('/tests')); ?>">Available Test</a>
                              <a class="nav-link" href="<?php echo e(url('/test-form')); ?>">Add Test</a>
                          </nav>
                      </div>
                      
                      
                      
                      <a class="nav-link" href="<?php echo e(url('consultations')); ?>">
                          <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                          Consultation
                      </a>
                      <a class="nav-link" href="<?php echo e(url('/lab')); ?>">
                          <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                          Laboratory
                      </a>
                  </div>
              </div>
              <div class="sb-sidenav-footer">
                  <div class="small">Logged in as:</div>
                  Start Bootstrap
              </div>
          </nav>
      </div>


<?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>