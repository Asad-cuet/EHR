

<?php $__env->startSection('title','Tests'); ?>
<?php $__env->startSection('content'); ?>



<table class="table">
   <thead>
     <tr>
       <th scope="col">ID</th>
       <th scope="col">Name</th>
     </tr>
   </thead>
   <tbody>
      <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
         <td><?php echo e($item['id']); ?></td>
         <td><?php echo e($item['test_name']); ?></td>
       </tr>       
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </tbody>
 </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/test/test_list.blade.php ENDPATH**/ ?>