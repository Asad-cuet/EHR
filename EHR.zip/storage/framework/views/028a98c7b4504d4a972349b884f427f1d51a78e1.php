

<?php $__env->startSection('title','Patient Registration'); ?>
<?php $__env->startSection('css'); ?>
<script>
      $(document).ready(function(){
            var cnt=2;
        $("#add").click(function(){
            var col="<div id='row"+cnt+"'><br><div class='row' ><select name='test[]' class='form-select' aria-label='Default select example'><option selected>Open this select menu</option><?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value='<?php echo e($item['id']); ?>'><?php echo e($item['test_name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div></div>";
            $(".box").append(col);
            cnt++;
        });
        $("#remove").click(function(){
            cnt--;
            var id="#row"+cnt;
            $(id).remove();
        });
      });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="" style="width:100%;max-width:700px;margin:auto">
<h3 class="text-center">Submit Test</h3>
<form method="POST" action="<?php echo e(url('/submit-exam/'.$consultation_id)); ?>">
      <?php echo csrf_field(); ?>

<div class="box">

      <div id="row1">
      <div class="row" >
            <select name="test[]" class="form-select" aria-label="Default select example">
                  <option selected>Open this select menu</option>
                  <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item['id']); ?>"><?php echo e($item['test_name']); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
      </div>
</div>

</div>      


      <br>
      <div class="text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      
</form>
<button class="btn btn-dark" id="add">Append an Input</button> 
<button class="btn btn-danger" id="remove">Remove an Input</button> 
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/consultation/action/exam.blade.php ENDPATH**/ ?>