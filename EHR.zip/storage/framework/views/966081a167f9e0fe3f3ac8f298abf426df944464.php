

<?php $__env->startSection('title','Doctors'); ?>
<?php $__env->startSection('content'); ?>



<table class="table">
   <thead>
     <tr>
       <th scope="col">ID</th>
       <th scope="col">Name</th>
       <th scope="col">Gender</th>
       <th scope="col">Phone</th>
       <th scope="col">Subject</th>
       <th scope="col">Action</th>
     </tr>
   </thead>
   <tbody>
      <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
         <td><?php echo e($item['id']); ?></td>
         <td><?php echo e($item['name']); ?></td>
         <td><?php echo e($item['gender']); ?></td>
         <td><?php echo e($item['phone']); ?></td>
         <td><?php echo e($item['subject']); ?></td>
         <td>
            <a href="<?php echo e(url('/doctor-view/'.$item['id'])); ?>" class="btn btn-secondary">View</a>
         </td>
         
       </tr>       
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </tbody>
 </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/doctor/doctor_list.blade.php ENDPATH**/ ?>