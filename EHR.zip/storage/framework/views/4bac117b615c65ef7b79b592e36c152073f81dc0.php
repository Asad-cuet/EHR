

<?php $__env->startSection('title','Patients'); ?>
<?php $__env->startSection('content'); ?>


<table class="table">
   <thead>
     <tr>
       <th scope="col">ID</th>
       <th scope="col">Name</th>
       <th scope="col">Gender</th>
       <th scope="col">Age</th>
       <th scope="col">Weight</th>
       <th scope="col">Phone</th>
       <th scope="col">Is Clear</th>
       <th scope="col">Action</th>
     </tr>
   </thead>
   <tbody>
      <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
         <td><?php echo e($item['id']); ?></td>
         <td><?php echo e($item['name']); ?></td>
         <td><?php echo e($item['gender']); ?></td>
         <td><?php echo e($item['age']); ?></td>
         <td><?php echo e($item['weight']); ?></td>
         <td><?php echo e($item['phone']); ?></td>
         <td>
          <?php if($item['is_cleared']): ?>
          <div class="badge  bg-success">Clear</div>
          <?php else: ?>
          <div class="badge  bg-danger">Not clear</div>    
          <?php endif; ?>
        </td>
         <td>
            <a href="<?php echo e(url('/patient-view/'.$item['id'])); ?>" class="btn btn-secondary">View</a>
            <?php if(!$item['is_consulted']): ?>
            <a href="<?php echo e(url('/consultant/'.$item['id'])); ?>" class="btn btn-primary">Consultation</a>
            <?php endif; ?>
         </td>
         
       </tr>       
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </tbody>
 </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/patient/patient_list.blade.php ENDPATH**/ ?>