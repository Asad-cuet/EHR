

<?php $__env->startSection('title','Patient View'); ?>
<?php $__env->startSection('content'); ?>


<div class="" style="width:100%;max-width:700px;margin:auto">
<h3 class="text-center">Patient View</h3>
<form method="POST" action="<?php echo e(url('/update-patient/'.$patient->id)); ?>">
      <?php echo csrf_field(); ?>

      <div class="row">
            <div class="col">
              <input required type="text" name="name" value="<?php echo e($patient->name); ?>" class="form-control" placeholder="Name" aria-label="First name">
            </div>
            <div class="col">
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="male" <?php if($patient->gender=='male'): ?> checked <?php endif; ?>>
                    <label class="form-check-label" for="flexRadioDefault1">
                      Male
                    </label>
                  </div>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="female" <?php if($patient->gender=='female'): ?> checked <?php endif; ?>>
                    <label class="form-check-label" for="flexRadioDefault2">
                      Female
                    </label>
                  </div>
          </div>
      </div>
      <br>
      <div class="row">
            <div class="col">
              <input required type="number" name="age" value="<?php echo e($patient->age); ?>" class="form-control" placeholder="Age" aria-label="First name">
            </div>
            <div class="col">
              <input required type="number" name="weight" value="<?php echo e($patient->weight); ?>" class="form-control" placeholder="Weight" aria-label="Last name">
            </div>
      </div>
      <br>
      <div class="row">
            <div class="col">
              <input required type="text" name="address" value="<?php echo e($patient->address); ?>" class="form-control" placeholder="Address" aria-label="First name">
            </div>
            <div class="col">
              <input required type="number" name="phone" value="<?php echo e($patient->phone); ?>" class="form-control" placeholder="Phone" aria-label="First name">
            </div>
      </div>
      <br>
      <div class="row">
            <div class="col">
              <input type="text" name="guardian_name" value="<?php echo e($patient->guardian_name); ?>" class="form-control" placeholder="Guardian Name (optional)" aria-label="First name">
            </div>
            <div class="col">
              <input type="number" name="guardian_phone" value="<?php echo e($patient->guardian_phone); ?>" class="form-control" placeholder="Guardian Phone (optional)" aria-label="First name">
            </div>
            <div class="col">
              <input type="text" name="relationship" value="<?php echo e($patient->relationship); ?>" class="form-control" placeholder="Relationship (optional)" aria-label="First name">
            </div>
      </div>
      <br>
      <div class="text-center">
            <button type="submit" class="btn btn-primary">Update</button>
      </div>
      
</form>
      
<br>

<ul class="list-group">
      <li class="list-group-item"><b>Login ID:</b> <?php echo e($patient->login_id); ?></li>
      <li class="list-group-item"><b>Password:</b> <?php echo e($patient->password); ?></li>
</ul>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR in Chiral Bangladesh\EHR\resources\views/pages/patient/patient_view.blade.php ENDPATH**/ ?>