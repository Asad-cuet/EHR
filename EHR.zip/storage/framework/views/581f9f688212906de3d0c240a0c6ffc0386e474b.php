

<?php $__env->startSection('title','Lab View'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
      <div class="col">
            <ul class="list-group">
                  
                  <li class="list-group-item active" aria-current="true">Patient Details</li>  
                  <li class="list-group-item" aria-current="true">Name: <?php echo e($lab->patient->name); ?></li>  
                  <li class="list-group-item" aria-current="true">Gender: <?php echo e($lab->patient->gender); ?></li>  
                  <li class="list-group-item" aria-current="true">Age: <?php echo e($lab->patient->age); ?></li>  
                  <li class="list-group-item" aria-current="true">Weight: <?php echo e($lab->patient->weight); ?></li>  
                  <li class="list-group-item" aria-current="true">Phone: <?php echo e($lab->patient->phone); ?></li>  
            </ul>
      </div>
      <div class="col">
            <form action="<?php echo e(url('/submit-report/'.$lab->id)); ?>" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
            <ul class="list-group">
                  <li class="list-group-item bg-danger text-white" aria-current="true">Exam</li>
                  <?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="list-group-item">
                        <b><?php echo e($item->test->test_name); ?></b>
                        <div class="">
                              <?php if(empty($item->report)): ?>
                              <input type="file" name="image[]">
                              <input type="hidden" name="test_id[]" value="<?php echo e($item->test_id); ?>">
                              <?php else: ?>
                              <div class="badge bg-success">Submitted</div>

                              <?php endif; ?>
                        </div>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                  <li class="list-group-item text-center" aria-current="true">
                  <button type="submit" class="btn btn-dark">Submit Report</button>      
                  </li>    
            </ul>
            </form>
      </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/lab/lab_view.blade.php ENDPATH**/ ?>