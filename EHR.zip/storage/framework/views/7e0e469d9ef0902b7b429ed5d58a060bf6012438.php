

<?php $__env->startSection('title','Patient Registration'); ?>
<?php $__env->startSection('content'); ?>


<div class="" style="width:100%;max-width:700px;margin:auto">
<h3 class="text-center">Submit Problem</h3>
<form method="POST" action="<?php echo e(url('/submit-problem/'.$consultation_id)); ?>">
      <?php echo csrf_field(); ?>

      <div class="row">
            <div class="col">
              <textarea required type="text"  name="problem_details" class="form-control" placeholder="Write Problems..." aria-label="First name"><?php if($consultation->problem_details): ?><?php echo e($consultation->problem_details); ?><?php endif; ?></textarea>
            </div>

      </div>
      <br>
      <div class="row">
            <div class="col">
              <input required type="text" name="problem_duration" class="form-control" placeholder="Problem Duration" aria-label="First name" <?php if($consultation->problem_details): ?> value="<?php echo e($consultation->problem_duration); ?>" <?php endif; ?>>
            </div>
      </div>
      <br>
      <div class="text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      
</form>
      
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/consultation/action/problem.blade.php ENDPATH**/ ?>