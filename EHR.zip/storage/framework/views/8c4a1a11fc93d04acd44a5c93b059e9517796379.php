

<?php $__env->startSection('title','Patients'); ?>
<?php $__env->startSection('content'); ?>
<?php if(session()->has('status')): ?>
      <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>   
      </div>                
<?php endif; ?>

<ul class="list-group">
      <li class="list-group-item bg-info" aria-current="true">Patient Basic Information</li>
      <li class="list-group-item"><b>Name : </b><?php echo e($consultation->patient->name); ?> </li>
      <li class="list-group-item"><b>Gender : </b><?php echo e($consultation->patient->gender); ?> </li>
      <li class="list-group-item"><b>Age : </b><?php echo e($consultation->patient->age); ?> </li>
      <li class="list-group-item"><b>Wight : </b><?php echo e($consultation->patient->weight); ?> </li>
      <li class="list-group-item"><b>Phone : </b><?php echo e($consultation->patient->phone); ?> </li>
      <li class="list-group-item"><b>Address : </b><?php echo e($consultation->patient->address); ?> </li>
      <li class="list-group-item"><b>Guardian Phone : </b><?php echo e($consultation->patient->guardian_phone); ?> </li>


      <li class="list-group-item bg-secondary text-white" aria-current="true">Doctor's Information</li>
      <li class="list-group-item"><b>Name : </b><?php echo e($consultation->doctor->name); ?> </li>
      <li class="list-group-item"><b>Subject : </b><?php echo e($consultation->doctor->subject); ?> </li>

      <li class="list-group-item bg-danger text-white" aria-current="true">Problem</li>
      <li class="list-group-item"><b>Details : </b><?php echo e($consultation->problem_details); ?> </li>
      <li class="list-group-item"><b>Duration : </b><?php echo e($consultation->problem_duration); ?> </li>

      <li class="list-group-item bg-warning text-white" aria-current="true">Doctor's Prescription</li>
      <?php $__currentLoopData = $consultation->prescribe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="list-group-item"><b><?php echo e($item['title']); ?> : </b> <?php echo e($item['comment']); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      


      <li class="list-group-item active" aria-current="true">Given Test</li>
      <?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item">
                  <b><?php echo e($item->test->test_name); ?> : </b> Image  
            </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <li class="list-group-item bg-success text-white" aria-current="true">Final Result</li>
      <li class="list-group-item">Normal </li>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/consultation/consultation_history.blade.php ENDPATH**/ ?>