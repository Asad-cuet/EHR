

<?php $__env->startSection('title','Patient Registration'); ?>
<?php $__env->startSection('css'); ?>
<script>
      $(document).ready(function(){
            var cnt=2;
        $("#add").click(function(){
            var col="<div id='row"+cnt+"'><br><div class='row'><div class='col'><input required type='text' name='title[]' class='form-control' placeholder='Title' aria-label='First name'></div><div class='col'><input required type='text' name='comment[]' class='form-control' placeholder='Comment' aria-label='First name'></div></div></div>";
            $(".box").append(col);
            cnt++;
        });
        $("#remove").click(function(){
            cnt--;
            var id="#row"+cnt;
            $(id).remove();
        });
      });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="" style="width:100%;max-width:700px;margin:auto">
<h3 class="text-center">Submit Prescribe</h3>
<form method="POST" action="<?php echo e(url('/submit-prescribe/'.$consultation_id)); ?>">
      <?php echo csrf_field(); ?>

<div class="box">

      <div id="row1">
      <div class="row" >
            <div class="col">
              <input required type="text" name="title[]" class="form-control" placeholder="Title" aria-label="First name">
            </div>
            <div class="col">
              <input required type="text" name="comment[]" class="form-control" placeholder="Comment" aria-label="First name">
            </div>
      </div>
</div>

</div>      


      <br>
      <div class="text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      
</form>
<button class="btn btn-dark" id="add">Append an Input</button> 
<button class="btn btn-danger" id="remove">Remove an Input</button> 
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\EHR\resources\views/pages/consultation/action/prescribe.blade.php ENDPATH**/ ?>